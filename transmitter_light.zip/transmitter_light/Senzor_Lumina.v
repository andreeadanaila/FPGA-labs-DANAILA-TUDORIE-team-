// =====================================================================
//  TRANSMITATOR DE LUMINA (placa cu LED-ul / laserul)
//
//  KEY3 apasat  -> trimite un octet (S1, S2 sunt bitii de jos)
//  KEY4 tinut   -> lumina aprinsa continuu (ca sa tintesti fotorezistorul)
//
//  Protocol (pe pinul tx_light, 1 = lumina aprinsa):
//    repaus = intuneric
//    1 bit START  = lumina
//    8 biti DATE  = LSB primul, 1 = lumina, 0 = intuneric
//    1 bit STOP   = intuneric
//  Fiecare bit dureaza 1/BIT_HZ secunde (implicit 100 ms -> 1 s / octet).
//  BIT_HZ trebuie sa fie ACELASI ca la receptor.
// =====================================================================
module Senzor_Lumina #(
    parameter CLK_HZ = 50_000_000,   // frecventa ceasului placii
    parameter BIT_HZ = 10            // biti pe secunda
)(
    input  wire clk,
    input  wire S1,
    input  wire S2,
    input  wire KEY3,
    input  wire KEY4,
    output wire led1,
    output wire led2,
    output wire led3,
    output wire buzzer,
    output wire tx_light     // pinul care aprinde LED-ul / laserul emitator
);

    localparam integer BIT_TICKS = CLK_HZ / BIT_HZ;

    // ------------------------------------------------------------
    // Sincronizare intrari (butoane presupuse active pe 0:
    // apasat = 0). Daca la tine sunt active pe 1, scoate "~" de jos.
    // ------------------------------------------------------------
    reg [1:0] k3_s = 2'b11, k4_s = 2'b11, s1_s = 2'b11, s2_s = 2'b11;

    always @(posedge clk) begin
        k3_s <= {k3_s[0], KEY3};
        k4_s <= {k4_s[0], KEY4};
        s1_s <= {s1_s[0], S1};
        s2_s <= {s2_s[0], S2};
    end

    wire send_btn = k3_s[1];   // 1 cand KEY3 e apasat
    wire aim_btn  = k4_s[1];   // 1 cand KEY4 e apasat
    wire b0       = s1_s[1];   // bitul 0 de date
    wire b1       = s2_s[1];   // bitul 1 de date

    // Octetul trimis. Poti pune orice aici, ex: 8'h41 (litera 'A').
    wire [7:0] data_in = {6'b000000, b1, b0};

    // Detectie front: o singura transmisie pe apasare
    reg  send_prev = 1'b0;
    wire send_press = send_btn & ~send_prev;

    // ------------------------------------------------------------
    // Emitator: registru de deplasare de 10 biti
    // ------------------------------------------------------------
    reg        busy    = 1'b0;
    reg [9:0]  frame   = 10'd0;
    reg [3:0]  bit_idx = 4'd0;
    reg [31:0] tick    = 32'd0;

    always @(posedge clk) begin
        send_prev <= send_btn;

        if (!busy) begin
            if (send_press) begin
                // {STOP=intuneric, DATE, START=lumina}; bitul 0 pleaca primul
                frame   <= {1'b0, data_in, 1'b1};
                busy    <= 1'b1;
                bit_idx <= 4'd0;
                tick    <= 32'd0;
            end
        end else begin
            if (tick == BIT_TICKS - 1) begin
                tick  <= 32'd0;
                frame <= {1'b0, frame[9:1]};     // urmatorul bit
                if (bit_idx == 4'd9)
                    busy <= 1'b0;                // gata, 10 biti trimisi
                else
                    bit_idx <= bit_idx + 4'd1;
            end else begin
                tick <= tick + 32'd1;
            end
        end
    end

    // Cat timp transmite -> bitul curent; altfel lumina doar daca tii KEY4
    wire light_on = busy ? frame[0] : aim_btn;

    // Daca emitatorul tau se aprinde pe 0, schimba in: assign tx_light = ~light_on;
    assign tx_light = ~light_on;

    // LED-urile de pe placa (active pe 0)
    assign led1 = ~light_on;   // arata ce se trimite
    assign led2 = ~busy;       // aprins cat dureaza transmisia
    assign led3 = 1'b1;        // stins

    assign buzzer = 1'b1;      // oprit

endmodule